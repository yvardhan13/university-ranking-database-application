<!DOCTYPE html>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
</style>
<?php
$conn=mysqli_connect("localhost","root","","project");
if(isset($_POST['Submit']))
{
$uniName= $_POST['uniName'];

}

$query="select uName,pName,aName,rank,year from university u join rank r on u.uId=r.uId join agency a on r.aId=a.aId join program p on r.pId=p.pId where u.uName like '%".$uniName."%';";

$result=mysqli_query($conn,$query) or die($query."<br/>".mysqli_error($conn));

echo "<table align=center> <tr><td><strong>University</strong></td><td><strong>Program</strong></td><td><strong>Agency</strong></td><td><strong>Rank</strong></td><td><strong>Year</strong></td></tr>"; 
while($row = mysqli_fetch_array($result))
{  

echo "<tr><td>" . $row['uName'] . "</td><td>" . $row['pName'] . "</td><td>" . $row['aName']. "</td><td>"  . $row['rank'] . "</td><td>". $row['year'] . "</td></tr>";

}
?>
<html lang="en">
	<head>
		<title>Fearless Ranking</title>
	</head>
	<body bgcolor="#E6E6FA">
	<h1><center>Fearless Rankings</center></h1>
	
	</body>
</html>
