<!DOCTYPE html>
  <html>
  <head>
  <style>
.center {
    margin: auto;
    width: 60%;
    border: 3px solid #28294C;
    padding: 70px;
}

</style>
<title>Fearless Rankings</title>
</head>
  <body bgcolor="#E6E6FA">
  <h1><center>Fearless Rankings</center></h1>
	<div class="center">
	<form action="databases.php" method="post">
	<div><label><strong>Agency</strong></label></div>
	<select name="aId">
		<option value="1001">US News</option>
		<option value="1002">Bloomberg Businessweek</option>
		<option value="1003">TFE times</option>
		<option value="1004">Eduniversal</option>
	</select>
	<div><label><strong>Program</strong></label></div>
	<select name="pId">
		<option value="001">MSIS</option>
		<option value="002">MSBA</option>
		<option value="003">MBA</option>
	</select>
	<div><label><strong>Year</strong></label></div>
	<select name="year">
		<option value="2016">2016</option>
		<option value="2015">2015</option>
	</select>
	<div><label><strong>Top</strong></label></div>
	<select name="top">
		<option value="10">10</option>
		<option value="5">5</option>
	</select>
	<br>
	<br>
	<input type="submit" class="submit" name="Submit">
	</form>
</div>
<div class="center">
<form action="databases2.php" method="post">
<div><label><strong>Select program to see historical rankings across different agencies</strong></label></div>
	<select name="pId">
		<option value="001">MSIS</option>
		<option value="002">MSBA</option>
		<option value="003">MBA</option>
	</select>
	<div><label><strong>Top</strong></label></div>
	<select name="top">
		<option value="10">10</option>
		<option value="5">5</option>
	</select>
<br>
<br>
<input type="submit" class="submit" name="Submit">
</form>
</div>
<div>

<div class="center">
<form action="databases3.php" method="post">
<div><label><strong>Enter univerisy's name</strong></label></div>
	<input type='text' name='uniName' id='uniName'>

<br>
<br>
<input type="submit" class="submit" name="Submit">
</form>
</div>
</body>
</html>
